# Loop Configuration — Minimal Triage (Codex)

## Active Loops

| Pattern | Cadence | Status | Automation prompt |
|---------|---------|--------|-------------------|
| Daily Triage | 1d | L1 report-only | `Run $zj-loop-triage. Read zj-loop/STATE.md. Report only.` |

## Human Gates

- No auto-fix until L2 checklist complete
- All high-risk paths: human review required (see zj-loop/zj-loop-safety.md denylist)

## Worktrees

- Codex provides a built-in worktree per thread — use it for L2+ fix attempts.
- One fix per worktree; verifier subagent must APPROVE before proposing a PR.

## Connectors (MCP)

- MCP optional for L1 report-only loops.
- For L2+: GitHub connector to read CI/issues; write scope limited to comments until trusted.

## Budget

- Max sub-agent spawns per run: 0 (L1)
- Review STATE.md daily + Codex Triage inbox

## Routing

- Route policy lives in `zj-loop/zj-loop-route-table.yaml`.
- Keep cross-component dispatch routes disabled until the consumer workflow and state owner are ready.

## Links

- Pattern: [daily-triage](../../patterns/daily-triage.md)
- Checklist: [loop-design-checklist](../../docs/loop-design-checklist.md)
